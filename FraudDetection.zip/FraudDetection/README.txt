Credit Card Fraud Detection (Random Forest)

1. pip install -r requirements.txt
2. python run_all.py        (about 2 minutes; creates data, model, graphs, database)

Outputs: outputs/graphs/, outputs/metrics.json, models/, database/predictions.db
Optional: python tools/build_report.py   (needs: pip install reportlab pillow)
