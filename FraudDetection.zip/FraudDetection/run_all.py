"""Run the complete pipeline from the command line.

    python run_all.py

Generates the dataset (if missing), cleans it, trains and saves the Random Forest,
evaluates it, saves graphs to outputs/graphs/, metrics to outputs/metrics.json and
logs sample predictions to database/predictions.db.
"""
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "data"))

from generate_dataset import generate
from src import visualize as viz
from src.evaluate import compare_models, confusion, money_impact
from src.predict import log_predictions, read_history, score_transactions
from src.preprocessing import build_features, load_data, split_data
from src.train import (choose_threshold, cv_results_table, fit_final_model,
                       save_model, tune_model)

CSV = ROOT / "data" / "transactions.csv"
GRAPHS = ROOT / "outputs" / "graphs"
GRAPHS.mkdir(parents=True, exist_ok=True)


def save(fig, name):
    fig.savefig(GRAPHS / name, dpi=150, bbox_inches="tight")
    plt.close(fig)


def main():
    if not CSV.exists():
        generate().to_csv(CSV, index=False)
    raw = load_data(CSV)
    X, y, df = build_features(raw)
    split = split_data(X, y, df)
    print(f"Rows: raw={len(raw)} clean={len(X)} train={len(split.X_train)} "
          f"test={len(split.X_test)} features={X.shape[1]} "
          f"fraud_train={int(split.y_train.sum())} fraud_test={int(split.y_test.sum())}")

    save(viz.plot_class_imbalance(df), "01_class_imbalance.png")
    save(viz.plot_fraud_patterns(df), "02_fraud_patterns.png")
    save(viz.plot_amount_ratio(df), "03_amount_ratio.png")

    search = tune_model(split.X_train, split.y_train)
    print("Best params:", search.best_params_,
          " CV PR-AUC: %.4f" % search.best_score_)
    top = cv_results_table(search)
    print(top.round(4).to_string())
    save(viz.plot_grid_search(top), "04_grid_search.png")

    model = fit_final_model(split.X_train, split.y_train, search.best_params_)
    threshold = choose_threshold(split.X_train, split.y_train, search.best_params_)
    print(f"Tuned decision threshold (from training data only): {threshold:.3f}")
    save_model(model, ROOT / "models" / "fraud_rf_model.joblib",
               search.best_params_, threshold)

    prob = model.predict_proba(split.X_test)[:, 1]
    table, results = compare_models(split, prob, threshold)
    pred = results["RF (tuned threshold)"][0]
    cm = confusion(split.y_test, pred)
    cm_default = confusion(split.y_test, results["RF (threshold 0.50)"][0])
    impact = money_impact(split.y_test, split.df_test["amount_inr"], results)
    print(table.to_string())
    print("Confusion (tuned):", cm, " | Confusion (0.50):", cm_default)
    print(impact.to_string())

    save(viz.plot_threshold_tradeoff(split.y_test, prob, threshold),
         "05_threshold_tradeoff.png")
    save(viz.plot_confusion(split.y_test, pred), "06_confusion_matrix.png")
    save(viz.plot_pr_curves(results, split.y_test), "07_pr_curves.png")
    save(viz.plot_importance(model), "08_feature_importance.png")
    save(viz.plot_model_comparison(table), "09_model_comparison.png")
    save(viz.plot_money_impact(impact), "10_money_impact.png")

    # log a few test transactions (4 frauds + 4 legitimate) to SQLite
    fr = split.y_test[split.y_test == 1].index[:4]
    lg = split.y_test[split.y_test == 0].index[:4]
    sample = score_transactions(model, threshold, X, df, list(fr) + list(lg))
    db = ROOT / "database" / "predictions.db"
    db.unlink(missing_ok=True)
    log_predictions(sample, db)
    print(read_history(db).to_string(index=False))

    out = {"best_params": search.best_params_, "cv_pr_auc": search.best_score_,
           "cv_top5": top.round(4).to_dict(orient="records"),
           "threshold": threshold, "confusion_tuned": cm,
           "confusion_default": cm_default,
           "comparison": table.to_dict(orient="index"),
           "money_impact": impact.to_dict(orient="index")}
    (ROOT / "outputs" / "metrics.json").write_text(
        json.dumps(out, indent=2, default=str))


if __name__ == "__main__":
    main()
