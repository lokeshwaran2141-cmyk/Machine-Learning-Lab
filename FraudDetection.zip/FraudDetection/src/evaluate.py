"""Classification metrics, baseline comparison and money impact."""
import numpy as np
import pandas as pd
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, average_precision_score,
                             confusion_matrix, f1_score, precision_score,
                             recall_score, roc_auc_score)
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


def classification_metrics(y_true, y_pred, y_prob):
    """Positive class = Fraud (1).  Accuracy is shown only to demonstrate why it
    is misleading when 98% of transactions are legitimate."""
    return {"Accuracy": accuracy_score(y_true, y_pred),
            "Precision": precision_score(y_true, y_pred, zero_division=0),
            "Recall": recall_score(y_true, y_pred),
            "F1": f1_score(y_true, y_pred, zero_division=0),
            "PR_AUC": average_precision_score(y_true, y_prob),
            "ROC_AUC": roc_auc_score(y_true, y_prob)}


def confusion(y_true, y_pred):
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    return {"TN": int(tn), "FP": int(fp), "FN": int(fn), "TP": int(tp)}


def baseline_models(split, threshold_lr=0.5):
    """Reference models: 'always legitimate' and class-weighted Logistic Regression."""
    dummy = DummyClassifier(strategy="most_frequent").fit(split.X_train, split.y_train)
    lr = make_pipeline(StandardScaler(),
                       LogisticRegression(max_iter=2000, class_weight="balanced"))
    lr.fit(split.X_train, split.y_train)
    p_lr = lr.predict_proba(split.X_test)[:, 1]
    return {"Always Legitimate": (dummy.predict(split.X_test),
                                  np.zeros(len(split.X_test))),
            "Logistic Regression": ((p_lr >= threshold_lr).astype(int), p_lr)}


def compare_models(split, rf_prob, threshold):
    results = {
        "RF (threshold 0.50)": ((rf_prob >= 0.5).astype(int), rf_prob),
        "RF (tuned threshold)": ((rf_prob >= threshold).astype(int), rf_prob),
        **baseline_models(split)}
    table = pd.DataFrame({n: classification_metrics(split.y_test, p, pr)
                          for n, (p, pr) in results.items()}).T
    return table.round(4), results


def money_impact(y_true, amounts, results):
    """Fraud money caught / missed and false alarms for every model."""
    y_true, amounts = np.asarray(y_true), np.asarray(amounts, float)
    total_fraud = amounts[y_true == 1].sum()
    rows = {}
    for name, (pred, _) in results.items():
        pred = np.asarray(pred)
        caught = amounts[(y_true == 1) & (pred == 1)].sum()
        rows[name] = {"fraud_caught_inr": caught,
                      "fraud_missed_inr": total_fraud - caught,
                      "false_alarms": int(((y_true == 0) & (pred == 1)).sum()),
                      "caught_%_of_fraud_value": 100 * caught / total_fraud}
    return pd.DataFrame(rows).T.round(1)
