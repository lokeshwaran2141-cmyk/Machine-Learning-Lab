"""Matplotlib graphs used in the report and saved by run_all.py."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import ConfusionMatrixDisplay, precision_recall_curve

from src.preprocessing import TARGET

plt.rcParams.update({"figure.dpi": 100, "axes.grid": True, "grid.alpha": 0.3,
                     "axes.spines.top": False, "axes.spines.right": False,
                     "font.size": 9, "axes.titlesize": 10})
LEGIT_C, FRAUD_C = "#2ca02c", "#d62728"
COLORS = ["#9ecae1", "#1f77b4", "#7f7f7f", "#ff7f0e"]   # RF 0.5, RF tuned, dummy, LR


def plot_class_imbalance(df):
    counts = df[TARGET].value_counts().sort_index()
    fig, ax = plt.subplots(figsize=(5.2, 3.2))
    bars = ax.bar(["Legitimate", "Fraud"], counts.values, color=[LEGIT_C, FRAUD_C])
    for b, v in zip(bars, counts.values):
        ax.text(b.get_x() + b.get_width() / 2, v + counts.max() * 0.01,
                f"{v:,} ({100 * v / counts.sum():.1f}%)", ha="center")
    ax.set(title="Class imbalance: legitimate vs fraudulent transactions",
           ylabel="Number of transactions")
    ax.set_ylim(0, counts.max() * 1.12)
    fig.tight_layout()
    return fig


def plot_fraud_patterns(df):
    fig, axes = plt.subplots(1, 2, figsize=(8.8, 3.3),
                             gridspec_kw={"width_ratios": [1.1, 1]})
    by_hour = 100 * df.groupby("hour")[TARGET].mean()
    axes[0].bar(by_hour.index, by_hour.values, color=FRAUD_C)
    axes[0].set(title="Fraud rate by hour of day", xlabel="Hour", ylabel="Fraud rate (%)")
    by_cat = (100 * df.groupby("category", observed=True)[TARGET].mean()).sort_values()
    axes[1].barh(by_cat.index, by_cat.values, color="#1f77b4")
    axes[1].set(title="Fraud rate by merchant category", xlabel="Fraud rate (%)")
    fig.tight_layout()
    return fig


def plot_amount_ratio(df):
    clip = df["amount_ratio"].clip(upper=10)
    fig, ax = plt.subplots(figsize=(7.0, 3.2))
    bins = np.linspace(0, 10, 41)
    ax.hist(clip[df[TARGET] == 0], bins=bins, density=True, alpha=0.7,
            color=LEGIT_C, label="Legitimate")
    ax.hist(clip[df[TARGET] == 1], bins=bins, density=True, alpha=0.7,
            color=FRAUD_C, label="Fraud")
    ax.set(title="Amount relative to the cardholder's usual spending",
           xlabel="Amount / 30-day average amount (capped at 10)", ylabel="Density")
    ax.legend()
    fig.tight_layout()
    return fig


def plot_grid_search(table):
    labels = [f"{r.n_estimators} trees\ndepth {r.max_depth}\nleaf {r.min_samples_leaf}"
              for r in table.itertuples()]
    fig, ax = plt.subplots(figsize=(8.0, 3.2))
    ax.bar(labels, table["cv_pr_auc"], yerr=table["cv_pr_auc_std"],
           color="#1f77b4", capsize=3)
    ax.set_ylim(max(0, (table["cv_pr_auc"] - table["cv_pr_auc_std"]).min() - 0.05), 1.0)
    ax.set(title="Top 5 parameter sets (5-fold cross-validated PR-AUC)",
           ylabel="Mean CV PR-AUC")
    ax.tick_params(axis="x", labelsize=7)
    fig.tight_layout()
    return fig


def plot_threshold_tradeoff(y_true, prob, threshold):
    thr = np.linspace(0.05, 0.95, 91)
    pred = prob[None, :] >= thr[:, None]
    y = np.asarray(y_true) == 1
    tp = (pred & y).sum(1)
    prec = tp / np.clip(pred.sum(1), 1, None)
    rec = tp / y.sum()
    f1 = 2 * prec * rec / np.clip(prec + rec, 1e-12, None)
    fig, ax = plt.subplots(figsize=(7.0, 3.4))
    ax.plot(thr, prec, label="Precision", color="#ff7f0e")
    ax.plot(thr, rec, label="Recall", color="#1f77b4")
    ax.plot(thr, f1, label="F1", color="#2ca02c", lw=2)
    ax.axvline(threshold, color="k", ls="--", lw=1,
               label=f"Tuned threshold = {threshold:.2f}")
    ax.set(title="Precision / recall trade-off vs decision threshold (test set)",
           xlabel="Decision threshold", ylabel="Score")
    ax.legend(fontsize=7)
    fig.tight_layout()
    return fig


def plot_confusion(y_true, y_pred):
    fig, ax = plt.subplots(figsize=(4.4, 3.8))
    ConfusionMatrixDisplay.from_predictions(
        y_true, y_pred, display_labels=["Legitimate", "Fraud"], cmap="Blues",
        ax=ax, colorbar=False)
    ax.grid(False)
    ax.set_title("Confusion matrix (test set, tuned threshold)")
    fig.tight_layout()
    return fig


def plot_pr_curves(results, y_true):
    fig, ax = plt.subplots(figsize=(5.4, 4.0))
    shown = {k: v for k, v in results.items()
             if k in ("RF (tuned threshold)", "Logistic Regression")}
    for (name, (_, prob)), c in zip(shown.items(), ["#1f77b4", "#ff7f0e"]):
        p, r, _ = precision_recall_curve(y_true, prob)
        ax.plot(r, p, color=c, lw=1.6, label=name.replace(" (tuned threshold)", ""))
    ax.axhline(np.mean(y_true), color="k", ls="--", lw=0.8, label="Random guess")
    ax.set(title="Precision-recall curves on the test set", xlabel="Recall",
           ylabel="Precision", ylim=(0, 1.02))
    ax.legend(fontsize=7)
    fig.tight_layout()
    return fig


def plot_importance(model, top=10):
    imp = pd.Series(model.feature_importances_, index=model.feature_names_in_)
    imp = imp.sort_values().tail(top)
    fig, ax = plt.subplots(figsize=(6.4, 3.6))
    ax.barh(imp.index, imp.values, color="#2ca02c")
    ax.set(title=f"Top {top} feature importances", xlabel="Importance")
    fig.tight_layout()
    return fig


def plot_model_comparison(table):
    metrics = ["Accuracy", "Precision", "Recall", "F1", "PR_AUC"]
    x = np.arange(len(metrics))
    n = len(table)
    w = 0.8 / n
    fig, ax = plt.subplots(figsize=(8.4, 3.5))
    for i, (name, c) in enumerate(zip(table.index, COLORS)):
        ax.bar(x + (i - (n - 1) / 2) * w, table.loc[name, metrics], w, color=c,
               label=name)
    ax.set_xticks(x, metrics)
    ax.set_ylim(0, 1.08)
    ax.set(title="Model comparison on the test set", ylabel="Score")
    ax.legend(fontsize=7, loc="upper center", ncol=4, bbox_to_anchor=(0.5, -0.12),
              frameon=False)
    fig.tight_layout()
    return fig


def plot_money_impact(impact):
    x = np.arange(len(impact))
    fig, ax = plt.subplots(figsize=(8.0, 3.4))
    ax.bar(x - 0.18, impact["fraud_caught_inr"] / 1000, 0.36, color=LEGIT_C,
           label="Fraud value caught")
    ax.bar(x + 0.18, impact["fraud_missed_inr"] / 1000, 0.36, color=FRAUD_C,
           label="Fraud value missed")
    ax.set_xticks(x, impact.index)
    ax.tick_params(axis="x", labelsize=7.5)
    ax.set(title="Value of fraudulent transactions caught vs missed (test set)",
           ylabel="Amount (thousand INR)")
    ax.legend(fontsize=8)
    fig.tight_layout()
    return fig
