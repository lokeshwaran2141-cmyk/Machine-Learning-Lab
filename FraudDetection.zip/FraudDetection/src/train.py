"""Tune, train and save the Random Forest fraud classifier."""
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import precision_recall_curve
from sklearn.model_selection import GridSearchCV, StratifiedKFold, cross_val_predict

RANDOM_STATE = 42
PARAM_GRID = {
    "n_estimators": [100, 200],
    "max_depth": [8, 12, None],
    "min_samples_leaf": [1, 3, 5],
}


def _rf(**params):
    # class_weight makes the rare fraud class count more during training
    return RandomForestClassifier(class_weight="balanced_subsample",
                                  random_state=RANDOM_STATE, n_jobs=-1, **params)


def cv_splitter(n_splits=5):
    return StratifiedKFold(n_splits, shuffle=True, random_state=RANDOM_STATE)


def tune_model(X_train, y_train):
    """Grid search with stratified 5-fold CV, scored by PR-AUC (average precision),
    which is far more informative than accuracy on imbalanced data."""
    search = GridSearchCV(_rf(), PARAM_GRID, cv=cv_splitter(),
                          scoring="average_precision", n_jobs=1)
    search.fit(X_train, y_train)
    return search


def cv_results_table(search, top=5):
    res = pd.DataFrame(search.cv_results_)
    res["cv_pr_auc"] = res["mean_test_score"]
    res["cv_pr_auc_std"] = res["std_test_score"]
    cols = ["param_n_estimators", "param_max_depth", "param_min_samples_leaf",
            "cv_pr_auc", "cv_pr_auc_std"]
    out = res.sort_values("cv_pr_auc", ascending=False)[cols].head(top)
    return out.reset_index(drop=True).rename(
        columns=lambda c: c.replace("param_", ""))


def fit_final_model(X_train, y_train, best_params):
    return _rf(**best_params).fit(X_train, y_train)


def choose_threshold(X_train, y_train, best_params):
    """Pick the decision threshold that maximises F1 on out-of-fold training
    predictions (the test set is not used)."""
    oof = cross_val_predict(_rf(**best_params), X_train, y_train, cv=cv_splitter(),
                            method="predict_proba")[:, 1]
    prec, rec, thr = precision_recall_curve(y_train, oof)
    f1 = 2 * prec[:-1] * rec[:-1] / np.clip(prec[:-1] + rec[:-1], 1e-12, None)
    return float(thr[int(np.argmax(f1))])


def save_model(model, path, best_params, threshold):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, path)
    meta = {"algorithm": "RandomForestClassifier", "best_params": best_params,
            "decision_threshold": threshold,
            "features": list(model.feature_names_in_),
            "classes": {"0": "Legitimate", "1": "Fraud"}}
    path.with_suffix(".json").write_text(json.dumps(meta, indent=2, default=str))
