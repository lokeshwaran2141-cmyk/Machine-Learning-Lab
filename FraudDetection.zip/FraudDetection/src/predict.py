"""Load the trained model, score transactions, and log predictions to SQLite."""
import datetime as dt
import json
import sqlite3
from pathlib import Path

import joblib
import pandas as pd

LABEL = {0: "Legitimate", 1: "Fraud"}


def load_model(path="models/fraud_rf_model.joblib"):
    """Return (model, decision threshold)."""
    path = Path(path)
    meta = json.loads(path.with_suffix(".json").read_text())
    return joblib.load(path), meta["decision_threshold"]


def score_transactions(model, threshold, X, df, rows):
    """Score the chosen rows of the engineered frame and compare with the truth."""
    prob = model.predict_proba(X.loc[rows])[:, 1]
    out = pd.DataFrame({
        "transaction_id": df.loc[rows, "transaction_id"].values,
        "amount_inr": df.loc[rows, "amount_inr"].values,
        "actual": df.loc[rows, "is_fraud"].map(LABEL).values,
        "predicted": pd.Series((prob >= threshold).astype(int)).map(LABEL).values,
        "fraud_prob": prob.round(3)})
    out["correct"] = (out["actual"] == out["predicted"]).astype(int)
    return out


def log_predictions(pred_df, db_path="database/predictions.db"):
    """Persist predictions (transaction, amount, actual, predicted, probability, time)."""
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.execute("""CREATE TABLE IF NOT EXISTS prediction_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        transaction_id INTEGER, amount_inr REAL, actual TEXT, predicted TEXT,
        fraud_prob REAL, correct INTEGER, created_at TEXT)""")
    now = dt.datetime.now().isoformat(timespec="seconds")
    conn.executemany(
        "INSERT INTO prediction_log (transaction_id, amount_inr, actual, predicted,"
        " fraud_prob, correct, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        [(int(r.transaction_id), float(r.amount_inr), r.actual, r.predicted,
          float(r.fraud_prob), int(r.correct), now) for r in pred_df.itertuples()])
    conn.commit()
    conn.close()


def read_history(db_path="database/predictions.db", limit=10):
    conn = sqlite3.connect(db_path)
    hist = pd.read_sql_query(
        "SELECT * FROM prediction_log ORDER BY id DESC LIMIT ?", conn,
        params=(limit,))
    conn.close()
    return hist
