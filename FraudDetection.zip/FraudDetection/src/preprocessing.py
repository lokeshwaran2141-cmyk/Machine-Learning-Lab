"""Data cleaning, feature engineering and stratified train/test split."""
from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

TARGET = "is_fraud"                       # 1 = Fraud, 0 = Legitimate
CATEGORIES = ["Grocery", "Fuel", "Restaurant", "Electronics", "Travel",
              "Online Shopping", "ATM Withdrawal"]
BASE_FEATURES = ["amount_inr", "avg_amount_30d", "distance_from_home_km",
                 "txns_last_24h", "account_age_days", "is_online", "is_foreign"]
ENGINEERED = ["hour", "day_of_week", "is_night", "amount_ratio", "log_amount"]
RANDOM_STATE = 42


def load_data(path):
    """Read the CSV, parse timestamps and sort in time order."""
    df = pd.read_csv(path, parse_dates=["timestamp"])
    return df.sort_values("timestamp").reset_index(drop=True)


def clean_data(df):
    """Remove duplicate transactions, impute missing values, validate the target."""
    df = df.drop_duplicates("transaction_id").copy()
    for col in ["distance_from_home_km", "avg_amount_30d"]:
        df[col] = df[col].fillna(df[col].median())           # robust to outliers
    df = df[df[TARGET].isin([0, 1])]
    df = df[df["amount_inr"] > 0]
    return df.reset_index(drop=True)


def add_features(df):
    """Time-based and behaviour-based features."""
    df = df.copy()
    df["hour"] = df["timestamp"].dt.hour
    df["day_of_week"] = df["timestamp"].dt.dayofweek
    df["is_night"] = ((df["hour"] <= 5) | (df["hour"] == 23)).astype(int)
    df["amount_ratio"] = df["amount_inr"] / df["avg_amount_30d"]   # vs usual spending
    df["log_amount"] = np.log1p(df["amount_inr"])
    return df


def build_features(raw_df):
    """Return X (features), y (fraud flag) and the engineered DataFrame."""
    df = add_features(clean_data(raw_df))
    df["category"] = pd.Categorical(df["category"], categories=CATEGORIES)
    dummies = pd.get_dummies(df["category"], prefix="cat", dtype=int)
    X = pd.concat([df[BASE_FEATURES + ENGINEERED], dummies], axis=1)
    return X, df[TARGET], df


@dataclass
class Split:
    X_train: pd.DataFrame
    X_test: pd.DataFrame
    y_train: pd.Series
    y_test: pd.Series
    df_test: pd.DataFrame


def split_data(X, y, df, test_size=0.2):
    """Stratified split keeps the same (tiny) fraud ratio in train and test."""
    idx_tr, idx_te = train_test_split(
        X.index, test_size=test_size, stratify=y, random_state=RANDOM_STATE)
    return Split(X.loc[idx_tr], X.loc[idx_te], y.loc[idx_tr], y.loc[idx_te],
                 df.loc[idx_te])
