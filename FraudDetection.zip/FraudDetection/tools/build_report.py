"""Build the project report PDF (same layout as the sample report).

Console outputs shown in the report come from the saved run results
(outputs/metrics.json) and from re-running the cheap project functions; the code
listings are read from the real source files.

Run: python tools/build_report.py   (after python run_all.py)
"""
import json
import sys
from pathlib import Path

import joblib
import matplotlib
import numpy as np
import pandas as pd
import sklearn
from PIL import Image as PILImage
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph,
                                Preformatted, SimpleDocTemplate, Spacer, Table,
                                TableStyle)

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src.predict import read_history
from src.preprocessing import TARGET, build_features, load_data, split_data

GR = ROOT / "outputs" / "graphs"
M = json.loads((ROOT / "outputs" / "metrics.json").read_text())
bp, thr = M["best_params"], M["threshold"]
comp = pd.DataFrame(M["comparison"]).T
impact = pd.DataFrame(M["money_impact"]).T
cmt, cmd = M["confusion_tuned"], M["confusion_default"]
rf, rft = comp.loc["RF (threshold 0.50)"], comp.loc["RF (tuned threshold)"]
lr, dm = comp.loc["Logistic Regression"], comp.loc["Always Legitimate"]
imp_rf, imp_lr = impact.loc["RF (tuned threshold)"], impact.loc["Logistic Regression"]

raw = load_data(ROOT / "data" / "transactions.csv")
X, y, df = build_features(raw)
split = split_data(X, y, df)
total_fraud_value = imp_rf["fraud_caught_inr"] + imp_rf["fraud_missed_inr"]

# ---------------------------------------------------------------- styles
ss = getSampleStyleSheet()
BODY = ParagraphStyle("body", parent=ss["Normal"], fontName="Times-Roman",
                      fontSize=11, leading=14.5, alignment=TA_JUSTIFY, spaceAfter=5)
H = ParagraphStyle("h", parent=BODY, fontName="Times-Bold", fontSize=12.5,
                   spaceBefore=10, spaceAfter=5, alignment=0)
TITLE = ParagraphStyle("t", parent=BODY, fontName="Times-Bold", fontSize=16,
                       leading=20, alignment=TA_CENTER, spaceAfter=10)
ITAL = ParagraphStyle("i", parent=BODY, fontName="Times-Italic")
CAP = ParagraphStyle("cap", parent=BODY, fontName="Times-Italic", fontSize=10.5,
                     alignment=TA_CENTER, spaceBefore=3, spaceAfter=10)
BUL = ParagraphStyle("bul", parent=BODY, leftIndent=14, bulletIndent=2, spaceAfter=2)
SUBH = ParagraphStyle("sh", parent=BODY, fontName="Times-Bold", fontSize=11.5,
                      spaceBefore=8, spaceAfter=3, alignment=0)
CODE = ParagraphStyle("code", fontName="Courier", fontSize=7.2, leading=8.6)
OUT = ParagraphStyle("out", fontName="Courier", fontSize=7.4, leading=9.0)


def P(t, s=BODY):
    return Paragraph(t, s)


def bullets(items):
    return [Paragraph(t, BUL, bulletText="•") for t in items]


def numbered(items):
    return [Paragraph(t, BUL, bulletText=f"{i}.") for i, t in enumerate(items, 1)]


def console(title, text):
    head = Table([[title]], colWidths=[16.6 * cm])
    head.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#1f3b63")),
                              ("TEXTCOLOR", (0, 0), (-1, -1), colors.white),
                              ("FONTNAME", (0, 0), (-1, -1), "Helvetica"),
                              ("FONTSIZE", (0, 0), (-1, -1), 8)]))
    body = Table([[Preformatted(text.rstrip("\n"), OUT)]], colWidths=[16.6 * cm])
    body.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#b8c2cc")),
                              ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f7f8fa")),
                              ("LEFTPADDING", (0, 0), (-1, -1), 6),
                              ("TOPPADDING", (0, 0), (-1, -1), 5),
                              ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
    return [head, body]


def figure(flow, caption):
    return KeepTogether(flow + [P(caption, CAP)])


def img(name, width_cm):
    p = GR / name
    w, h = PILImage.open(p).size
    return Image(str(p), width=width_cm * cm, height=width_cm * cm * h / w)


def fmt(df_, **kw):
    return df_.to_string(**kw)


# ------------------------------------------------------- captured outputs
n_fraud = int((raw.drop_duplicates("transaction_id")[TARGET] == 1).sum())
step1 = (f"Shape: {raw.shape} | Date range: {raw['timestamp'].min().date()} to "
         f"{raw['timestamp'].max().date()}\n"
         f"Merchant categories: {raw['category'].nunique()} | Frauds: {n_fraud}\n\n"
         + fmt(raw[["transaction_id", "category", "amount_inr", "avg_amount_30d",
                    "is_online", "is_fraud"]].head(4)) + "\n\n"
         + fmt(raw[["amount_inr", "avg_amount_30d", "distance_from_home_km",
                    "txns_last_24h", "account_age_days"]].describe().round(2)))

miss = raw.isna().sum()
miss = miss[miss > 0]
step2 = ("Missing values BEFORE cleaning:\n"
         + "".join(f"  {k:<24}{v}\n" for k, v in miss.items())
         + f"Duplicate transactions         : {int(raw.duplicated('transaction_id').sum())}\n"
         f"Rows after cleaning            : {len(X)}\n"
         f"Missing values AFTER cleaning  : {int(df.isna().sum().sum())}\n"
         f"Fraud rate                     : {100 * y.mean():.2f}% "
         f"({int(y.sum())} of {len(y)})\n\n"
         f"Features after engineering: {X.shape[1]} "
         f"(7 base + 5 engineered + 7 one-hot categories)\n"
         f"Train: {len(split.X_train)} rows (Fraud {int(split.y_train.sum())}, "
         f"Legitimate {int((split.y_train == 0).sum())})\n"
         f"Test : {len(split.X_test)} rows (Fraud {int(split.y_test.sum())}, "
         f"Legitimate {int((split.y_test == 0).sum())})")

cv = pd.DataFrame(M["cv_top5"])
step4 = (f"Best parameters: {bp}\nBest 5-fold CV PR-AUC: {M['cv_pr_auc']:.4f}\n\n"
         + fmt(cv) + f"\n\nTuned decision threshold (from training data only): {thr:.3f}")

step5 = ("Confusion matrix, tuned threshold : "
         f"TN={cmt['TN']}  FP={cmt['FP']}  FN={cmt['FN']}  TP={cmt['TP']}\n"
         "Confusion matrix, threshold 0.50  : "
         f"TN={cmd['TN']}  FP={cmd['FP']}  FN={cmd['FN']}  TP={cmd['TP']}\n\n"
         + fmt(comp.astype(float).round(4)))

step6 = fmt(impact.astype(float).round(1))
hist = read_history(ROOT / "database" / "predictions.db", limit=8)
step7 = fmt(hist, index=False)

tree = """FraudDetection
|-- data
|   |-- generate_dataset.py
|   `-- transactions.csv
|-- database
|   `-- predictions.db
|-- models
|   |-- fraud_rf_model.joblib
|   `-- fraud_rf_model.json
|-- outputs
|   |-- graphs
|   |   |-- 01_class_imbalance.png
|   |   |-- 02_fraud_patterns.png
|   |   |-- 03_amount_ratio.png
|   |   |-- 04_grid_search.png
|   |   |-- 05_threshold_tradeoff.png
|   |   |-- 06_confusion_matrix.png
|   |   |-- 07_pr_curves.png
|   |   |-- 08_feature_importance.png
|   |   |-- 09_model_comparison.png
|   |   `-- 10_money_impact.png
|   `-- metrics.json
|-- report
|   `-- Credit_Card_Fraud_Detection_Report.pdf
|-- src
|   |-- __init__.py
|   |-- preprocessing.py
|   |-- train.py
|   |-- evaluate.py
|   |-- predict.py
|   `-- visualize.py
|-- tools
|   `-- build_report.py
|-- requirements.txt
`-- run_all.py"""

# ------------------------------------------------------------ story
S = []
S.append(P("Credit Card Fraud Detection using Machine Learning "
           "(Random Forest Classification on Imbalanced Data)", TITLE))

S.append(P("Problem Statement:", H))
S.append(P(
    "Banks and payment companies process millions of card transactions every day. A very "
    "small fraction of them are fraudulent – stolen card details used for a large "
    "online purchase at night, a sudden burst of transactions, or a purchase far from the "
    "cardholder's home – but each one costs the customer and the bank real money. "
    "Rule-based checks written by hand either miss new patterns or block too many genuine "
    "customers, and a human cannot review every transaction."))
S.append(P(
    "Fraud detection is also a difficult machine learning problem because the data is "
    "<b>highly imbalanced</b>: here only 2% of transactions are fraud. A model that "
    "declares every transaction legitimate is 98% accurate and completely useless, so "
    "accuracy cannot be used to judge it. What matters is how many frauds are caught "
    "(recall), how many alerts are real (precision), and how many genuine customers are "
    "wrongly blocked (false alarms)."))
S.append(P(
    "This project designs and implements a Credit Card Fraud Detection system in Python 3. "
    "It performs data cleaning, behaviour and time-based feature engineering, and "
    "classification with a class-weighted Random Forest tuned with cross-validation on "
    "PR-AUC, selects a decision threshold, and evaluates the model on unseen transactions "
    "using precision, recall, F1, PR-AUC, ROC-AUC, the confusion matrix and the money value "
    "of the fraud caught and missed, against two baseline models."))

S.append(P("Objectives:", H))
S += numbered([
    "To collect and organise a transaction dataset containing amount, merchant category, "
    "time, cardholder history, location/channel flags and a fraud label.",
    "To clean the data by removing duplicate transactions, imputing missing values and "
    "validating the target variable.",
    "To engineer meaningful features (hour, night flag, amount relative to the cardholder's "
    "usual spending, log amount, one-hot encoded merchant category).",
    "To handle the class imbalance with a stratified split and class-weighted training, and "
    "to tune a Random Forest with stratified 5-fold cross-validation scored by PR-AUC.",
    "To choose the decision threshold from training data only, evaluate on an unseen test "
    "set (precision, recall, F1, PR-AUC, ROC-AUC, confusion matrix), and compare with "
    "baseline models.",
    "To estimate the money value of fraud caught and missed and to persist every "
    "prediction (transaction id, amount, actual and predicted label, fraud probability, "
    "timestamp) in an SQLite database.",
])

S.append(P("Software / Hardware Required:", H))
S += bullets([
    "Operating System: Windows / Linux / macOS (executed on Linux)",
    "Environment: JupyterLab or any Python IDE; the whole pipeline also runs from the "
    "command line with <font name='Courier'>python run_all.py</font>",
    f"Language: Python 3.x (executed with Python {sys.version.split()[0]})",
    f"Machine Learning: scikit-learn {sklearn.__version__} (RandomForestClassifier, "
    "GridSearchCV, StratifiedKFold)",
    f"Data Handling: pandas {pd.__version__}, NumPy {np.__version__}",
    f"Visualization: Matplotlib {matplotlib.__version__}",
    f"Model Persistence: joblib {joblib.__version__}",
    "Database: SQLite3 (prediction log)",
    f"Dataset: Synthetic card-transaction data – {len(raw):,} records "
    f"({len(X):,} unique transactions plus 15 duplicates), 2025-01-01 to 2025-06-30, "
    f"generated by data/generate_dataset.py with a fixed random seed (42); "
    f"{int(y.sum())} frauds ({100 * y.mean():.1f}%)",
    "Hardware: Standard CPU-only computer; no GPU required",
])
S.append(P(
    "Data note: no real transaction records were available (real card data is private), "
    "so the dataset is synthetic and is produced from explicit, documented rules. About "
    "30% of the simulated frauds are deliberately made to look almost like normal "
    "purchases. All results therefore describe performance on simulated data. Replacing "
    "data/transactions.csv with real records that have the same columns allows the same "
    "code to be retrained without modification.", ITAL))

S.append(P("Project Directory Structure:", H))
S.append(P("The project (“FraudDetection”) is organized with separate folders for "
           "the dataset, source modules, trained model, outputs, database and report, as "
           "shown below."))
S.append(figure(console("Project folder", tree),
                "Fig 1: Project directory structure of FraudDetection"))

S.append(P("Procedure:", H))
S += numbered([
    "Prepare the dataset: run <font name='Courier'>data/generate_dataset.py</font> to create "
    "<font name='Courier'>data/transactions.csv</font>.",
    "Install the libraries listed in requirements.txt.",
    "Load the CSV file and inspect its shape, summary statistics and the fraud rate (Step 1).",
    "Clean the data – remove duplicate transactions, impute missing distance and "
    "average-amount values with the median, validate the target (Step 2).",
    "Engineer features – hour, day of week, night flag, amount-to-usual-spending ratio, "
    "log amount and one-hot encoded merchant category (19 features) – and analyse "
    "fraud patterns by hour, category and amount (Step 3).",
    "Split the data 80/20 with a stratified split so train and test both keep the 2% "
    "fraud rate (Step 2).",
    "Tune the Random Forest (class-weighted) with GridSearchCV and 5-fold stratified "
    "cross-validation scored by PR-AUC (Step 4).",
    "Train the final model with the best parameters, choose the decision threshold from "
    "out-of-fold training predictions, and save the model to "
    "models/fraud_rf_model.joblib (Step 4).",
    "Evaluate on the held-out test set – precision, recall, F1, PR-AUC, ROC-AUC, "
    "confusion matrix, feature importance, baseline comparison and money impact (Steps 5 "
    "and 6).",
    "Log predictions into the SQLite database database/predictions.db and display the "
    "prediction history (Step 7).",
])

S.append(P("Implementation Code:", H))
S.append(P("Complete implementation of the modules used in the project (identical to the "
           "source files in the project folder)."))

files = [
    ("1. Synthetic Dataset Generation (data/generate_dataset.py)", "data/generate_dataset.py"),
    ("2. Data Cleaning and Feature Engineering (src/preprocessing.py)", "src/preprocessing.py"),
    ("3. Model Tuning and Training (src/train.py)", "src/train.py"),
    ("4. Model Evaluation (src/evaluate.py)", "src/evaluate.py"),
    ("5. Prediction and Saving Prediction History (src/predict.py)", "src/predict.py"),
    ("6. Visualization (src/visualize.py)", "src/visualize.py"),
    ("7. Pipeline Runner (run_all.py)", "run_all.py"),
]
for title, rel in files:
    text = (ROOT / rel).read_text().rstrip("\n")
    assert max(len(l) for l in text.splitlines()) <= 105, rel
    S.append(P(title, SUBH))
    S.append(Preformatted(text, CODE))
    S.append(Spacer(1, 6))

S.append(PageBreak())
S.append(P("Output (Step-by-Step Results):", H))
S.append(P("All outputs below were produced by running the project code. Console outputs "
           "are the actual printed results of the modules and the graphs are the actual "
           "images saved in outputs/graphs/. No value has been edited by hand."))

S.append(figure(console("Step 1 · Load dataset", step1),
                "Fig 2: Step 1 — Load dataset: shape, first rows and summary statistics"))
S.append(figure([img("01_class_imbalance.png", 9.5)],
                f"Fig 3: Step 1 — Class imbalance ({int(y.sum())} frauds among "
                f"{len(y):,} transactions)"))
S.append(figure(console("Step 2 · Cleaning and split", step2),
                "Fig 4: Step 2 — Data cleaning checks and the stratified 80/20 split"))
S.append(figure([img("02_fraud_patterns.png", 16)],
                "Fig 5: Step 3 — Fraud rate by hour of day and by merchant category"))
S.append(figure([img("03_amount_ratio.png", 13)],
                "Fig 6: Step 3 — Amount relative to usual spending, legitimate vs fraud"))
S.append(figure(console("Step 4 · Hyper-parameter tuning", step4),
                "Fig 7: Step 4 — Random Forest grid search (5-fold stratified CV, "
                "PR-AUC) and chosen threshold"))
S.append(figure([img("04_grid_search.png", 14.5)],
                "Fig 8: Step 4 — Top five parameter sets by cross-validated PR-AUC"))
S.append(figure([img("05_threshold_tradeoff.png", 13)],
                "Fig 9: Step 5 — Precision, recall and F1 against the decision threshold"))
S.append(figure(console("Step 5 · Test-set metrics and baselines", step5),
                "Fig 10: Step 5 — Performance on the unseen test set and comparison "
                "with baseline models"))
S.append(figure([img("06_confusion_matrix.png", 8)],
                "Fig 11: Step 5 — Confusion matrix of the Random Forest (tuned threshold)"))
S.append(figure([img("07_pr_curves.png", 10)],
                "Fig 12: Step 5 — Precision-recall curves of the Random Forest and "
                "Logistic Regression"))
S.append(figure([img("09_model_comparison.png", 15)],
                "Fig 13: Step 5 — Metric comparison of the four models"))
S.append(figure([img("08_feature_importance.png", 11.5)],
                "Fig 14: Step 5 — Top 10 feature importances of the Random Forest"))
S.append(figure(console("Step 6 · Money impact (test set)", step6),
                "Fig 15: Step 6 — Value of fraud caught and missed, and number of "
                "false alarms"))
S.append(figure([img("10_money_impact.png", 14.5)],
                "Fig 16: Step 6 — Fraud value caught vs missed for each model"))
S.append(figure(console("Step 7 · Prediction history (SQLite)", step7),
                "Fig 17: Step 7 — Prediction history log persisted in the SQLite database"))

S.append(P("Result:", H))
S.append(P(
    "A Credit Card Fraud Detection system was successfully designed and implemented in "
    "Python 3 using pandas, scikit-learn (class-weighted Random Forest) and an SQLite "
    f"database. After cleaning ({len(raw):,} records reduced to {len(X):,} unique "
    f"transactions; {int(y.sum())} frauds, 2.0%), the tuned model "
    f"({bp['n_estimators']} trees, unlimited depth, minimum samples per leaf "
    f"{bp['min_samples_leaf']}; cross-validated PR-AUC {M['cv_pr_auc']:.3f}) was trained on "
    f"{len(split.X_train):,} transactions and tested on {len(split.X_test):,} unseen ones "
    f"containing {int(split.y_test.sum())} frauds. With the threshold chosen from training "
    f"data ({thr:.2f}) it reached precision {rft['Precision']:.3f}, recall "
    f"{rft['Recall']:.3f}, F1 {rft['F1']:.3f}, PR-AUC {rft['PR_AUC']:.3f} and ROC-AUC "
    f"{rft['ROC_AUC']:.3f}: {cmt['TP']} frauds were caught, {cmt['FN']} were missed and "
    f"{cmt['FP']} genuine transactions were wrongly flagged. By value, the model caught "
    f"{imp_rf['caught_%_of_fraud_value']:.1f}% of the fraudulent amount "
    f"(INR {imp_rf['fraud_caught_inr']:,.0f} of INR {total_fraud_value:,.0f})."))
S.append(P(
    "These figures must be read with care. First, the dataset is synthetic and about 30% "
    "of its frauds were designed to look normal, so the numbers show that the pipeline "
    "works, not how accurate it would be on real transactions. Second, the test set holds "
    f"only {int(split.y_test.sum())} frauds, so every missed fraud moves recall by more "
    "than one percentage point and the results carry wide uncertainty. Third, accuracy is "
    f"misleading: the Random Forest scores {rft['Accuracy']:.4f}, but a model that "
    f"flags nothing already scores {dm['Accuracy']:.4f}. Fourth, the tuned threshold did "
    f"not help on the test set (F1 {rf['F1']:.3f} at 0.50 against {rft['F1']:.3f} at "
    f"{thr:.2f}), because the training-based choice landed almost exactly on 0.50."))
S.append(P(
    "The comparison with Logistic Regression shows a real trade-off rather than a clear "
    f"winner. Logistic Regression (class-weighted, default threshold 0.50, not tuned) "
    f"ranks transactions slightly better (PR-AUC {lr['PR_AUC']:.3f} against "
    f"{rft['PR_AUC']:.3f}) and catches more fraud (recall {lr['Recall']:.3f}, "
    f"{imp_lr['caught_%_of_fraud_value']:.1f}% of fraud value), but it raises "
    f"{int(imp_lr['false_alarms'])} false alarms with precision of only "
    f"{lr['Precision']:.3f}. The Random Forest raises just {int(imp_rf['false_alarms'])} "
    "false alarms but misses nearly half of the frauds. Which is better depends on the "
    "bank's cost of a missed fraud against the cost of blocking a genuine customer, and "
    "a fair comparison would tune the threshold of both models to that cost."))
S.append(P(
    "In conclusion, a class-weighted Random Forest given amount, behaviour, time and "
    "channel features detects fraud far better than the “always legitimate” "
    "rule and produces few false alarms, with amount relative to usual spending, "
    "transactions in the last 24 hours and distance from home as the strongest signals, "
    "and every prediction is logged in a database. Next steps are to retrain on real "
    "transaction data, tune the decision threshold to an explicit cost of missed fraud "
    "versus false alarms, try gradient boosting, and validate on a later time period."))

# ----------------------------------------------------------- build
out_dir = ROOT / "report"
out_dir.mkdir(exist_ok=True)
out = out_dir / "Credit_Card_Fraud_Detection_Report.pdf"


def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Times-Roman", 9)
    canvas.drawCentredString(A4[0] / 2, 1.1 * cm, str(doc.page))
    canvas.restoreState()


doc = SimpleDocTemplate(str(out), pagesize=A4, leftMargin=2.2 * cm, rightMargin=2.2 * cm,
                        topMargin=2 * cm, bottomMargin=2 * cm,
                        title="Credit Card Fraud Detection using Random Forest",
                        author="")
doc.build(S, onFirstPage=footer, onLaterPages=footer)
print("Wrote", out)
