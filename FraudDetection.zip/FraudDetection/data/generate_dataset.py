"""Generate a reproducible SYNTHETIC dataset of credit card transactions.

No real customer data is used.  Every row is produced from the explicit rules
below with a seeded NumPy generator, so the CSV is fully reproducible.  Replace
data/transactions.csv with real records (same columns) to retrain the model.

About 2% of the transactions are fraudulent.  Roughly 70% of the frauds follow an
"obvious" pattern (unusually large amount, night time, far from home, foreign or
online, many transactions in a day).  The other 30% are "subtle" frauds that look
almost like normal purchases, so the problem is realistically hard.

Run: python data/generate_dataset.py
"""
from pathlib import Path

import numpy as np
import pandas as pd

SEED = 42
N = 20000
FRAUD_RATE = 0.02
START, END = "2025-01-01", "2025-06-30"

CATEGORIES = ["Grocery", "Fuel", "Restaurant", "Electronics", "Travel",
              "Online Shopping", "ATM Withdrawal"]
LEGIT_P = [0.25, 0.15, 0.20, 0.07, 0.05, 0.20, 0.08]
FRAUD_P = [0.03, 0.03, 0.04, 0.25, 0.15, 0.40, 0.10]
# typical amount multiplier of each category
CAT_MULT = {"Grocery": 0.8, "Fuel": 0.9, "Restaurant": 0.7, "Electronics": 2.5,
            "Travel": 3.0, "Online Shopping": 1.2, "ATM Withdrawal": 1.5}
ONLINE_P = {"Grocery": 0.03, "Fuel": 0.02, "Restaurant": 0.10, "Electronics": 0.50,
            "Travel": 0.60, "Online Shopping": 1.00, "ATM Withdrawal": 0.00}
# hourly weights (0..23) for normal behaviour: busy 9am-9pm, quiet at night
HOUR_W = np.array([1, 1, 1, 1, 1, 2, 3, 5, 7, 9, 10, 10,
                   11, 10, 9, 9, 9, 10, 10, 9, 7, 5, 3, 2], float)


def generate(n=N, seed=SEED):
    rng = np.random.default_rng(seed)
    is_fraud = rng.random(n) < FRAUD_RATE
    obvious = is_fraud & (rng.random(n) < 0.70)      # clear fraud pattern
    subtle = is_fraud & ~obvious                     # fraud that looks normal

    # ---- category ------------------------------------------------------
    category = np.where(
        is_fraud,
        rng.choice(CATEGORIES, n, p=FRAUD_P),
        rng.choice(CATEGORIES, n, p=LEGIT_P))

    # ---- time ----------------------------------------------------------
    days = (pd.Timestamp(END) - pd.Timestamp(START)).days + 1
    day = rng.integers(0, days, n)
    hour_legit = rng.choice(24, n, p=HOUR_W / HOUR_W.sum())
    hour_night = rng.choice([0, 1, 2, 3, 4, 5, 23], n)
    hour = np.where(obvious & (rng.random(n) < 0.60), hour_night, hour_legit)
    ts = (pd.Timestamp(START) + pd.to_timedelta(day, unit="D")
          + pd.to_timedelta(hour, unit="h")
          + pd.to_timedelta(rng.integers(0, 60, n), unit="m"))

    # ---- cardholder history -------------------------------------------
    avg_amount = rng.lognormal(np.log(1500), 0.45, n)             # INR, 30-day mean
    account_age = rng.integers(30, 3000, n)
    account_age = np.where(obvious & (rng.random(n) < 0.35),
                           rng.integers(5, 120, n), account_age)

    # ---- amount --------------------------------------------------------
    mult = np.array([CAT_MULT[c] for c in category])
    ratio = rng.lognormal(0, 0.55, n) * mult
    ratio = np.where(obvious, rng.lognormal(np.log(3.2), 0.6, n), ratio)
    ratio = np.where(subtle, ratio * rng.uniform(1.0, 1.6, n), ratio)
    amount = (avg_amount * ratio).round(2).clip(10, 150000)

    # ---- location / channel -------------------------------------------
    p_online = np.array([ONLINE_P[c] for c in category])
    is_online = (rng.random(n) < p_online).astype(int)
    is_online = np.where(obvious & (rng.random(n) < 0.55), 1, is_online)
    distance = rng.exponential(8.0, n)                            # km from home
    distance = np.where(obvious, rng.exponential(70.0, n), distance)
    distance = np.where(subtle, rng.exponential(18.0, n), distance)
    # for online purchases the distance is only a rough IP-location estimate
    distance = np.where(is_online == 1, rng.exponential(25.0, n) * (1 + obvious),
                        distance)
    foreign_p = np.where(obvious, 0.28, np.where(subtle, 0.05, 0.015))
    is_foreign = (rng.random(n) < foreign_p).astype(int)
    txns_24h = rng.poisson(np.where(obvious, 4.5, np.where(subtle, 2.0, 1.4))) + 1

    df = pd.DataFrame({
        "transaction_id": np.arange(100001, 100001 + n),
        "timestamp": ts,
        "category": category,
        "amount_inr": amount,
        "avg_amount_30d": avg_amount.round(2),
        "distance_from_home_km": distance.round(1),
        "txns_last_24h": txns_24h,
        "account_age_days": account_age,
        "is_online": is_online,
        "is_foreign": is_foreign,
        "is_fraud": is_fraud.astype(int)})
    df = df.sort_values("timestamp").reset_index(drop=True)

    # ---- data-quality problems (handled in preprocessing) -------------
    miss_d = rng.random(len(df)) < 0.015
    miss_a = rng.random(len(df)) < 0.010
    df.loc[miss_d, "distance_from_home_km"] = np.nan
    df.loc[miss_a, "avg_amount_30d"] = np.nan
    dupes = df.sample(15, random_state=seed)                     # duplicated rows
    df = pd.concat([df, dupes]).sort_values("timestamp").reset_index(drop=True)
    return df


if __name__ == "__main__":
    out = Path(__file__).resolve().parent / "transactions.csv"
    data = generate()
    data.to_csv(out, index=False)
    print(f"Saved {len(data)} rows to {out}")
